package com.cg.sms.bean;

import com.cg.sms.exception.StudentException;

public interface IStudentService {
	 	boolean addValidStudent(StudentData sdata)throws StudentException; 
}
