package com.cg.sms.bean;

import com.cg.sms.exception.StudentException;

public interface SmsDataOperation {

		void addStudent() throws StudentException;
		void modifyStudent();
		void showStudent();
}
