package com.cg.sms.bean;

import java.time.LocalDate;
import java.util.Scanner;

import com.cg.sms.exception.StudentException;

public class AdminSmsOperation implements SmsDataOperation {
	
	StudentData data = new StudentData();
	static Scanner scanner= new Scanner(System.in);
	IStudentService valid = new StudentServiceImpl();
	private LocalDate dateOfJoining;
	@Override
	public void addStudent() throws StudentException {
		// TODO Auto-generated method stub
	
		System.out.println("Enter Roll Number :");
		data.setRollNo(scanner.next());
		System.out.println("Enter Name :");
		data.setName(scanner.next());
		System.out.println("Enter Fee :");
		data.setFee((float)scanner.nextDouble());
		System.out.println("Enter Phone Number :");
		data.setPhoneNumber(scanner.next());
		if(valid.addValidStudent(data)){}
		else{this.data = new StudentData();}
		
		
		
//		student.setDateOfJoining(dateOfJoining.dateInput());
	}

	@Override
	public void modifyStudent() {
		// TODO Auto-generated method stub
		System.out.println("Modify Student");
	
		System.out.println(data.getRollNo());
		System.out.println(data.getName());
		System.out.println(data.getFee());
		
	}

	@Override
	public void showStudent() {
		// TODO Auto-generated method stub
		StudentData showData = new StudentData();
		if(data.getRollNo()==null || data.getName()==null || data.getFee()==0.0 || data.getPhoneNumber()==null)
		{
			System.out.println("No data to Display");
		}
		
		else{
		System.out.println("Roll Number : ");
		System.out.println(data.getRollNo());
		System.out.println("Name of Student : ");
		System.out.println(data.getName());
		System.out.println("Total Fee : ");
		System.out.println(data.getFee());
		System.out.println("Phone Number of Student : ");
		System.out.println(data.getPhoneNumber());
		}
		
	}
	
}
