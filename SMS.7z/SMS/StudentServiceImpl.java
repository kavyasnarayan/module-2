package com.cg.sms.bean;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.sms.exception.StudentException;

public class StudentServiceImpl implements IStudentService {

	
	private boolean isValidSName(String name) throws StudentException {
		// TODO Auto-generated method stub
		Pattern namePattern = Pattern.compile("^[A-Z][A-Za-z\\s]{3,10}$");
		Matcher nameMatcher = namePattern.matcher(name);
		
		boolean isValid=nameMatcher.matches();
		if(!isValid)
			throw new StudentException("Name must start with Capital and must be atleast three chars in length.!!");
		return isValid;
	}
	
	private boolean isValidPhoneNumber(String phoneNumber) throws StudentException {
		// TODO Auto-generated method stub
		Pattern phoneNumberPattern = Pattern.compile("^\\d{10}$");
		Matcher phoneNumberMatcher = phoneNumberPattern.matcher(phoneNumber);
		
		boolean isValid=phoneNumberMatcher.matches();
		if(!isValid)
			throw new StudentException("Phone number Must be 10 digits.");
		return isValid;
	}
	
	private boolean isValidRollNumber(String rollNo) throws StudentException {
		// TODO Auto-generated method stub
		Pattern rollNoPattern = Pattern.compile("^\\d{2}$");
		Matcher phoneNumberMatcher = rollNoPattern.matcher(rollNo);
		
		boolean isValid=phoneNumberMatcher.matches();
		if(!isValid)
			throw new StudentException("Roll number Must be 2 digits.");
		return isValid;
	}

	
	private boolean isValid(StudentData sdata) throws StudentException {
		// TODO Auto-generated method stub
		return (isValidSName(sdata.getName())&&isValidPhoneNumber(sdata.getPhoneNumber())&&isValidRollNumber(sdata.getRollNo()));
	}
		

	@Override
	public boolean addValidStudent(StudentData sdata) throws StudentException {
		// TODO Auto-generated method stub
		boolean flag =false;
		try{
	if(sdata!=null && isValid(sdata))
	{
		flag=true;
		
	}
		}catch(StudentException exception)
		{
			System.err.println(exception.getMessage());
		}
		finally{
			return flag;
		}
		
			
		}

	
	}


	
