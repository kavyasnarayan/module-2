package com.cg.sms.pl;

import java.util.Scanner;

import com.cg.sms.bean.AdminSmsOperation;
import com.cg.sms.bean.SmsDataOperation;
import com.cg.sms.bean.StudentData;
import com.cg.sms.exception.StudentException;

public class MainStudentUI {


	public static void main(String args[]) throws StudentException {
	
	int choice=1;
	char option;
	SmsDataOperation dataOperation= new AdminSmsOperation();
	Scanner scanner = new Scanner(System.in);
	StudentData data = new StudentData();
	do{
	System.out.println("Select Menu:\n1.Add Student\n2.Modify Student\n3.Show Student\n4.Exit\nEnter your choice:");
	choice=scanner.nextInt();
    switch (choice)
    {
    case 1:
      System.out.println("Add Student");
      dataOperation.addStudent();
      
      break;
    case 2:
      System.out.println("Modify Student");
      dataOperation.modifyStudent();
      break;
    case 3:
	  System.out.println("Show Student");
	  dataOperation.showStudent();
	  break;
	  
    case 4:
    	System.out.println("Exit");
    	System.exit(0);
		break;
		
    default:
      System.out.println("Enter correct Choice.!!");

    }
    System.out.println("Do you Want to Continue (Y) :");
    option=scanner.next().charAt(0);
	}while(option== 'Y');

	}
}
