package com.cg.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	private static Connection connection;
	public static Connection getConnection() throws SQLException{
		if(connection==null){
			String url="jdbc:oracle:thin:@localhost:1521:xe";
			String user="system";
			String password="root";
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			connection = DriverManager.getConnection(url, user, password);	
		}
		return connection;
	}
}
