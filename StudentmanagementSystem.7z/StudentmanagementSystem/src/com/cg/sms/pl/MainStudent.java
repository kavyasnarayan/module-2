package com.cg.sms.pl;

import java.util.Scanner;

import com.cg.sms.service.IstudentService;
import com.cg.sms.service.StudentServiceImpl;
import com.cg.sms.bean.StudentBean;
import com.cg.sms.exception.StudentException;

public class MainStudent {

	public static void main(String[] args) throws StudentException {
		// TODO Auto-generated method stub
		
		
		StudentBean student=new StudentBean();
		String option= null;
	    Scanner in = new Scanner(System.in);
	    StudentBean bean = null;
	       do 
  			{
	    	   
	    	   System.out.println("STUDENT MANAGEMENT SYATEM");
	    	   System.out.println("__________________________");
	    	   System.out.println("\nOption1. Add new student");
		       System.out.println("\nOption2. Modify student details");
		       System.out.println("\nOption3. Show student details");
		       System.out.println("\nOption4. Exit");
		       System.out.println("\nEnter your option(1-4):");  
		       option=in.next();  
             
		    
		       StudentServiceImpl studentServiceImpl=null;
			switch (option)
            	{
			
             	case "1":
             		System.out.println("\nEnter Student Roll Number");
    				String rollNum=in.next();
    			 	student.setRollNo(rollNum);
    			 	
    			 	System.out.println("\nEnter Student Name");
    			 	String Name=in.next();
    			 	student.setsName(Name);
    			 	
    			 	
    			 	System.out.println("\nEnter your PhoneNumer");
    			   	String phoneNumber=in.next();
    			   	student.setPhoneNumber(phoneNumber);
    			   
    			    
    			 	System.out.println("\nEnter Student Date of Joining in the format of DD/MON/YYYY");
    			 	String date=in.next();
    			 	student.setDateOfJoining(date);
    			 	
    			 	
    			 	System.out.println("\nEnter course fees");
    			 	double fees=in.nextDouble();
    			 	student.setFees(fees);
    			    studentServiceImpl =new StudentServiceImpl();
    			 	try 
                     {
    			 			if(studentServiceImpl.isValidate(student)==false){
                               System.out.println("Invalid data"); 
                               if(studentServiceImpl.addDetails(bean)){
                            	   System.out.println("Data entered successfully!!!");
                               }
                               else{
                            	   System.out.println("enter the correct data!!!");
                               }
    			 			}
    			 			
                              
                      }
    
                     catch (StudentException e) 
                     {
                           System.err.println(e.getMessage() + " try again");
                     }
                     break;
                     
             		case "2":
             		System.out.println("\nEnter Modified Student Roll Number");
	       		   	  String rollNo=in.next();
	       		   	  student.setRollNo(rollNo);
	       		   	  
	       		   	  System.out.println("\nEnter Modified Student Name");
	       		   	  String sName=in.next();
	       		   	  student.setsName(sName);
	       		   	  
	       		   	  
	       		   	  System.out.println("\nEnter your PhoneNumer");
	       		   	  String sPhoneNumber=in.next();
	       		   	  student.setPhoneNumber(sPhoneNumber);
	       		   	 
	       		   	  
	       		   	  System.out.println("\nEnter modified Student Date of Joining in the format of DD/MON/YYYY");
	       		   	  String mDate=in.next();
	       		   	  student.setDateOfJoining(mDate);
	       		   	  
	       		   	  
	       		   	  System.out.println("\nEnter modified course fees\n");
	       		   	  double sFees=in.nextDouble();
	       		   	  student.setFees(sFees);
	       		   	  studentServiceImpl =new StudentServiceImpl();
		       		   try 
	                   {
	                        if(studentServiceImpl.isValidate(student)==true){
	                           System.out.println("Invalid data");
	                             }
	                        else
	                        {
	                        	
								studentServiceImpl.addDetails(bean);
	                        }
	                   } 
	                   catch (StudentException e) 
	                   {
	                       System.err.println(e.getMessage() + " try again");
	                   }
                   
	             	  break;
	             	  
             		case "3":
             		  System.out.println("\nRoll Number: "+student.getRollNo());
            	  	  System.out.println("\nName: "+student.getsName());
            	  	  System.out.println("\nPhone Number"+ student.getPhoneNumber());
            	  	  System.out.println("\nDate of Joining: "+student.getDateOfJoining());
            	  	  System.out.println("\ncourse fees: "+student.getFees());
            	  	  break;
            	  	  
             	case "4":
             			System.out.println("\nYou exit from the system");
             			break;
             			
             	default:
             			System.out.println("\nPlease Enter your choice from 1 to 4");
             			break;  
            	}
            	System.out.println("\nDo you want to continue? (Y/N)");
            	char decision=in.next().charAt(0);
            	
            		if(decision=='Y')
                    {
                                    continue;
                    }
                    else
                    {
                                    break;
                    }
  			}
  			while(!option.equals("4"));
            in.close();  
  			}
		
		
	}


