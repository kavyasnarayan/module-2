package com.cg.sms.pl;

import java.util.Scanner;

import com.cg.sms.service.StudInterface;
import com.cg.sms.service.StudentRecord;
import com.cg.sms.bean.BeanStudent;

public class MainStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BeanStudent student=new BeanStudent();
		StudInterface studentDetail= new StudentRecord ();
		
		int option=0;
	       Scanner in = new Scanner(System.in);
		
	       do 
  			{
          System.out.println("Option1. Add new student");
          System.out.println("Option2. Modify student details");
          System.out.println("Option3. Show student details");
          System.out.println("OPtion4. Exit");
          System.out.println("Enter your option(1-4):");  
          option=in.nextInt();  
             
            switch (option)
            	{
             	case 1:
             		studentDetail.addDetails();
            	 	break;
             	case 2:
             		studentDetail.modifyDetails();
             		break;
             	case 3:
             		studentDetail.displayDetails();
             		break;
             	case 4:break;
             	default:break;  
            	}
  			}
  			while(option<4);
            in.close();  
  			}
		
		
	}


