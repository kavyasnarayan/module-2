package com.cg.sms.dao;

public interface StudentQuery {
	public static final String RETRIVE_ALL_QUERY="SELECT rollNo,sName,phoneNumber,dateOfJoining,fees FROM StudentBean";
	public static final String VIEW_DONAR_DETAILS_QUERY="SELECT rollNo,sName,phoneNumber,dateOfJoining,fees FROM  StudentBean WHERE  rollNo=?";
	public static final String INSERT_QUERY="INSERT INTO StudentBean VALUES(sequence.NEXTVAL,?,?,?,?)";
	public static final String STUDENT_QUERY_SEQUENCE="SELECT sequence.CURRVAL FROM DUAL";
}