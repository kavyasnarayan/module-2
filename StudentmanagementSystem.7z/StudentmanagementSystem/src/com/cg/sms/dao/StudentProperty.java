package com.cg.sms.dao;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Properties;

public class StudentProperty {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		Properties properties=new Properties();
		properties.setProperty("user", "system");
		properties.setProperty("password", "root");
		properties.setProperty("url", "jdbc:oracle:thin:@localhost:1521:xe");
		
		OutputStream outputStream= new FileOutputStream("resources/dbprob.properties");
		properties.store(outputStream, "kavya!");
		outputStream.close();
		System.out.println("done");
	}

}
