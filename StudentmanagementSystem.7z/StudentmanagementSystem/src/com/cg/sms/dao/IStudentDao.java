package com.cg.sms.dao;

import java.util.List;

import com.cg.sms.bean.StudentBean;
import com.cg.sms.exception.StudentException;


public interface IStudentDao {

	public boolean addDetails(StudentBean bean) throws StudentException;
//	public StudentBean modifyDetails(StudentBean bean) throws StudentException;
	public StudentBean displayDetails(StudentBean bean) throws StudentException;
	public List<StudentBean> retriveAllDetails() throws Exception;
}
