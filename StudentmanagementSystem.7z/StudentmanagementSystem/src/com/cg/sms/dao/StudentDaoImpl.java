package com.cg.sms.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Properties;

import com.cg.sms.bean.StudentBean;
import com.cg.sms.exception.StudentException;
import com.cg.util.DBConnection;

public class StudentDaoImpl implements IStudentDao{

	@Override
	public boolean addDetails(StudentBean bean) throws StudentException {
		// TODO Auto-generated method stub
		try {
			Connection connection=DBConnection.getConnection();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		boolean result=false;
		Properties properties = new Properties();
		InputStream inputStream = null;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		Statement statement=null;
		ResultSet resultSet=null;
		try {
			inputStream = new FileInputStream("resources/dbprob.properties");
			properties.load(inputStream);
			String user = properties.getProperty("user");
			String password = properties.getProperty("password");
			String url = properties.getProperty("url");
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			connection = DriverManager.getConnection(url, user, password);
			connection.setAutoCommit(false);
			preparedStatement = connection.prepareStatement(StudentQuery.INSERT_QUERY);
			//preparedStatement.setString(1, bean.getRollNo());
			preparedStatement.setString(1, bean.getsName());
			preparedStatement.setString(2, bean.getPhoneNumber());
			preparedStatement.setString(3, bean.getDateOfJoining());
			preparedStatement.setDouble(4, bean.getFees());
			int result1 = preparedStatement.executeUpdate();
			 statement=connection.createStatement();
             resultSet=statement.executeQuery(StudentQuery.STUDENT_QUERY_SEQUENCE);
			if (result1 == 1) {
				connection.commit();
                 System.out.println("Student id is generated");
                
				//return value as to be added
		}
			} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			try {
				connection.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			if(preparedStatement !=null && connection !=null){
				try {
					preparedStatement.close();
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}
		return true;
	}

//	@Override
//	public StudentBean modifyDetails(StudentBean bean) throws StudentException {
//		// TODO Auto-generated method stub
//		
//		Properties properties = new Properties();
//		InputStream inputStream = null;
//		Connection connection = null;
//		PreparedStatement preparedStatement = null;
//		Statement statement=null;
//		ResultSet resultSet=null;
//		try {
//			inputStream = new FileInputStream("resources/dbprob.properties");
//			properties.load(inputStream);
//			String user = properties.getProperty("User");
//			String password = properties.getProperty("password");
//			String url = properties.getProperty("url");
//			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
//			connection = DriverManager.getConnection(url, user, password);
//			connection.setAutoCommit(false);
//			preparedStatement = connection.prepareStatement(StudentQuery.INSERT_QUERY);
//			preparedStatement.setString(1, bean.getRollNo());
//			preparedStatement.setString(2, bean.getsName());
//			preparedStatement.setString(3, bean.getPhoneNumber());
//			preparedStatement.setString(4, bean.getDateOfJoining());
//			preparedStatement.setDouble(5, bean.getFees());
//			int result1 = preparedStatement.executeUpdate();
//			if (result1 == 1) {
//				 statement=connection.createStatement();
//                 resultSet=statement.executeQuery(StudentQuery.STUDENT_QUERY_SEQUENCE);
//                if(resultSet.next()){
//                       System.out.println("Student generated id is"+resultSet.getInt(1));
//                }
//
//				connection.commit();
//				//return value as to be added
//		}
//			} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		return null;
//	}

	@Override
	public StudentBean displayDetails(StudentBean bean) throws StudentException {
		// TODO Auto-generated method stub
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		Connection connection=null;
		try {
			preparedStatement=connection.prepareStatement(StudentQuery.VIEW_DONAR_DETAILS_QUERY);
			preparedStatement.setString(1,bean.getRollNo());
			resultset=preparedStatement.executeQuery();
			if(resultset.next())
			{
				bean= new StudentBean();
				bean.setRollNo(resultset.getString(1));
				bean.setsName(resultset.getString(2));
				bean.setPhoneNumber(resultset.getString(3));
				bean.setDateOfJoining(resultset.getString(4));
				bean.setFees(resultset.getDouble(5));
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return null;
	}

	@Override
	public List<StudentBean> retriveAllDetails() throws Exception {
		// TODO Auto-generated method stub
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		Connection connection=null;
		StudentBean bean =null;
		preparedStatement=connection.prepareStatement(StudentQuery.RETRIVE_ALL_QUERY);
		resultset=preparedStatement.executeQuery();
		while (resultset.next()) {
			
			bean= new StudentBean();
			bean.setRollNo(resultset.getString(1));
			bean.setsName(resultset.getString(2));
			bean.setPhoneNumber(resultset.getString(3));
			bean.setDateOfJoining(resultset.getString(4));
			bean.setFees(resultset.getDouble(5));
		}
		return null;
	}
	

}
