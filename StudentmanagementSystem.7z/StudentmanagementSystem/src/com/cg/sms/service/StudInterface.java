package com.cg.sms.service;

public interface StudInterface {

	void addDetails();
	void modifyDetails();
	void displayDetails();
}
