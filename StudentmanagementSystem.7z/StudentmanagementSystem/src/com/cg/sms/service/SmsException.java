package com.cg.sms.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class SmsException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			String regex="^\\qd{3}$";
			Pattern pattern=Pattern.compile(regex);
			Matcher matcher= pattern.matcher(setRollNo());
			if(matcher.matches()){
				System.out.println("Its a number");
			}
			else
			{
				System.out.println("Not a number");
			}
			}catch(PatternSyntaxException exception){
				System.out.println("solve the exception\n"+exception.getMessage());
			}
		
	}

}
