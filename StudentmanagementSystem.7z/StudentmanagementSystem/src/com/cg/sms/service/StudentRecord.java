package com.cg.sms.service;

import java.util.Scanner;

import com.cg.sms.bean.BeanStudent;

public class StudentRecord implements StudInterface{
	
	Scanner in = new Scanner(System.in);
	BeanStudent student=new BeanStudent();
	
	public void addDetails() {
		System.out.println("Enter Student Roll Number\n");
	 	int rollNum=in.nextInt();
	 	student.setRollNo(rollNum);
	 	System.out.println("Enter Student Name\n");
	 	String Name=in.next();
	 	student.setsName(Name);
	 	System.out.println("Enter Student Date of Joining in the format of DD-MON-YYYY\n");
	 	String date=in.next();
	 	student.setDateOfJoining(date);
	 	System.out.println("Enter course fees\n");
	 	double fees=in.nextDouble();
	 	student.setFees(fees);
	}
	public void modifyDetails(){
	  System.out.println("Enter Modified Student Roll Number\n");
   	  int rollNo=in.nextInt();
   	  student.setRollNo(rollNo);
   	  System.out.println("Enter Modified Student Name\n");
   	  String sName=in.next();
   	  student.setsName(sName);
   	  System.out.println("Enter modified Student Date of Joining in the format of DD-MON-YYYY\n");
   	  String mDate=in.next();
   	  student.setDateOfJoining(mDate);
   	  System.out.println("Enter modified course fees\n");
   	  double sFees=in.nextDouble();
   	  student.setFees(sFees);
		
	}
	public void displayDetails()
	{
	  System.out.println(" Roll Number: "+student.getRollNo());
  	  System.out.println(" Name: "+student.getsName());
  	  System.out.println("  Date of Joining: "+student.getDateOfJoining());
  	  System.out.println(" course fees: "+student.getFees());

	}
}
