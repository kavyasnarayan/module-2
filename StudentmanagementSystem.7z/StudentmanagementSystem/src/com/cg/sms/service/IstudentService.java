package com.cg.sms.service;

import java.util.List;

import com.cg.sms.bean.StudentBean;
import com.cg.sms.exception.StudentException;

public interface IstudentService{

	public boolean addDetails(StudentBean bean) throws StudentException;
//	public StudentBean modifyDetails(StudentBean bean) throws StudentException;
	public StudentBean displayDetails(StudentBean bean) throws StudentException;
	public List<StudentBean> retriveAll() throws Exception;
}
 