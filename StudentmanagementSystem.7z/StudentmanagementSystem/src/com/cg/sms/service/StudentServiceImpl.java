package com.cg.sms.service;

import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.sms.bean.StudentBean;
import com.cg.sms.dao.StudentDaoImpl;
import com.cg.sms.exception.StudentException;


public class StudentServiceImpl implements IstudentService{
	
	Scanner in = new Scanner(System.in);
	StudentBean student=new StudentBean();
	StudentDaoImpl daoImpl=new StudentDaoImpl();
	

		public boolean isValidate(StudentBean bean) throws StudentException{
		
			String errorMessage="";
			String studentName= null;
			String studentRollNo = null;
			String phoneNumber=null;
			String dateOfjoining=null;
			double fees = 0.0d;
			
			//Validating StudentRollNo
			/****************************************************************************************************/
			studentRollNo = bean.getRollNo();
		
			Pattern rollNoPattern = Pattern.compile("^\\d{2}$");
			Matcher rollNoMatcher = rollNoPattern.matcher(studentRollNo);
		
			if(!(rollNoMatcher.matches()))
			{
				errorMessage+="\nRoll number Must be minimum 2 digits.";
			}
			/****************************************************************************************************/
			
			
			
			//validating student Name 
			/****************************************************************************************************/
			studentName=bean.getsName();
			
			Pattern namePattern = Pattern.compile("^[A-Z][A-Za-z\\s]{3,10}$");
			Matcher nameMatcher = namePattern.matcher(studentName);
			if(!(nameMatcher.matches()))
			{
				errorMessage+="\nName must start with Capital and contains atleast three chars in length.!!";
			}
			/****************************************************************************************************/
			
			
			//Validating student phoneNumber
			/****************************************************************************************************/
			
			phoneNumber=bean.getPhoneNumber();
			
			Pattern phoneNumberPattern = Pattern.compile("^\\d{10}$");
		
			Matcher phoneNumberMatcher = phoneNumberPattern.matcher(phoneNumber);
			if(!(phoneNumberMatcher.matches()))
			{
				errorMessage+="\nPhone number Must be 10 digits,no other character is allowed except number.";
			}
			/****************************************************************************************************/
			//validating Date of joining
			/****************************************************************************************************/
	
			dateOfjoining=bean. getDateOfJoining();
			
			Pattern datepattern = Pattern.compile("^[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}$");
			Matcher dateMatcher = datepattern.matcher(dateOfjoining);
			
			if(!(dateMatcher.matches()))
			{
				errorMessage+="\nEnter the date of joining in the format dd/mm/yyyy";
			}
			/****************************************************************************************************/
			
			//validating fees
			/****************************************************************************************************/
			fees = bean.getFees();
			
			if(fees<0)
			{
				errorMessage+="\nFees Should be a positive Number.";	
			}
			//valid phone
//			Pattern pattern=Pattern.compile("^\\d{10}$");
//			Matcher matcher= pattern.matcher(bean.getPhoneNumber());
//			if(matcher.matches()){
//				errorMessage+="Phone";
//			}
		/****************************************************************************************************/	
			boolean flag=true;
			 if(!errorMessage.isEmpty())
			 {
				 flag=false;
             throw new StudentException(errorMessage);
			 }
			return flag;
			
        
		}



		@Override
		public boolean addDetails(StudentBean bean) throws StudentException {
			// TODO Auto-generated method stub
			boolean studentdetails;
			studentdetails=daoImpl.addDetails(bean);
			return studentdetails;
			
		}


/*
		@Override
		public StudentBean modifyDetails(StudentBean bean)throws StudentException {
			// TODO Auto-generated method stub
			daoImpl.modifyDetails(bean);
			return null;
		}
*/


		@Override
		public StudentBean displayDetails(StudentBean bean)throws StudentException {
			// TODO Auto-generated method stub
			return null;
		}



		@Override
		public List<StudentBean> retriveAll() throws Exception {
			// TODO Auto-generated method stub
			return null;
		}



		public StudentBean modifyDetails(StudentBean bean)
				throws StudentException {
			// TODO Auto-generated method stub
			return null;
		}
		}

		

	
		

