package com.cg.sms.bean;

public class BeanStudent {

	public BeanStudent() {
		
		// TODO Auto-generated constructor stub
	}//Constructor is created
	
	private int rollNo;
	private String sName;
	private String dateOfJoining;
	private double fees;
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public String getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(String dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public double getFees() {
		return fees;
	}
	public void setFees(double fees) {
		this.fees = fees;
	}
	
	
	

}
