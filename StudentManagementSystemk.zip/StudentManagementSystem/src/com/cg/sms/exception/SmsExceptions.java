package com.cg.sms.exception;

public class SmsExceptions extends Exception{

	public SmsExceptions(String message) {
	super(message);
	}
	
}
