package com.cg.sms.pl;



import java.util.ArrayList;
import java.util.Scanner;

import com.cg.sms.bean.StudentData;
import com.cg.sms.exception.SmsExceptions;
import com.cg.sms.service.AdminSmsImpl;
import com.cg.sms.service.Istudent;

public class StudentMain {


	public static void main(String args[]) throws SmsExceptions {
	
	int choice;
	char option;
	Istudent dataOperation= new AdminSmsImpl();
	Scanner scanner = new Scanner(System.in);

	do{
	System.out.println("Select Menu:\n1.Add Student\n2.Modify Student\n3.Show Student\n4.Exit\nEnter your choice:");
	choice=scanner.nextInt();
	StudentData student = new StudentData();
    switch (choice)
    {
    case 1:
      System.out.println("Add Student");
      System.out.println("Enter Roll Number :");
		student.setRollNo(scanner.next());
		
		System.out.println("Enter Name :");
		student.setName(scanner.next());
		
		System.out.println("Enter Fees :");
		student.setFee(scanner.next());
		try{
			if(dataOperation.isValidData(student)) {
      if(dataOperation.addStudent(student)){
    	  System.out.println("Your data successful");
      }
      else{
    	  System.out.println("enter the correct data");
      }}}
			catch(Exception ex){
				System.out.println(ex.getMessage());
				
			}
      break;
    case 2:
      System.out.println("Modify Student");
      dataOperation.modifyStudent();
      break;
    case 3:
	  System.out.println("Show Student");
	  //dataOperation.showStudent();

		  ArrayList<StudentData> list=dataOperation.showStudent();
		for (StudentData studentDetails : list) {
			System.out.println("Roll no="+studentDetails.getRollNo());
			System.out.println("Name="+studentDetails.getName());
			System.out.println("Fee="+studentDetails.getFee());
			
			
		} 

	
	  break;
	  
    case 4:
    	System.out.println("Exit");
    	System.exit(0);
		break;
		
    default:
      System.out.println("Enter correct Choice.!!");

    }
    System.out.println("Do you Want to Continue (Y) :");
    option=scanner.next().charAt(0);
	}while(option== 'Y');

	}
}