package com.cg.sms.dao;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Scanner;

import com.cg.sms.bean.StudentData;
import com.cg.sms.exception.SmsExceptions;

public class SmsDaoImpl implements ISmsDao{
@Override
public String addStudent(StudentData student) throws SmsExceptions {
	Properties properties = new Properties();
	InputStream inputStream;
	try {
		inputStream = new FileInputStream("resources/dbresources.properties");
		properties.load(inputStream);
	} catch (FileNotFoundException e1) {
		System.out.println("File not found");
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	String url=properties.getProperty("url");
	String user=properties.getProperty("user");
	String password=properties.getProperty("password");
	
	Connection connection = null;
	PreparedStatement pst = null;
	ResultSet resultSet = null;
	try {
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		connection=
				DriverManager.getConnection(url,user,password);
		connection.setAutoCommit(false);
		pst=connection.prepareStatement(QueryMapper.INSERT_QUERY);

		pst.setString(1,student.getName() );
		pst.setString(2,student.getFee());
		int result=pst.executeUpdate();
		pst= connection.prepareStatement(QueryMapper.seq_SEQUENCE);
		resultSet=pst.executeQuery();
		if(result==1){
			connection.commit();
			System.out.println("Done Dude...Congrats!");
		}
	} catch (SQLException e) {
		try {
			connection.rollback();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		e.printStackTrace();
	}
	finally{
		if(pst!=null&&connection!=null){
			try {
				resultSet.close();
				pst.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	return null;
}
}
