package com.cg.sms.dao;

import java.util.ArrayList;

import com.cg.sms.bean.StudentData;
import com.cg.sms.exception.SmsExceptions;

public interface ISmsDao {
	public String addStudent(StudentData student) throws SmsExceptions;
}
