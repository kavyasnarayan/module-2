package com.cg.sms.dao;

public interface QueryMapper {
	public static final String SHOW_StudentDetails_QUERY="SELECT rollno,name,fee FROM student_details";
	public static final String INSERT_QUERY="INSERT INTO student_details VALUES(seq.NEXTVAL,?,?)";
	public static final String seq_SEQUENCE="SELECT seq.CURRVAL FROM DUAL";
	
}
