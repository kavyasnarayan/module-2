package com.cg.sms.service;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.sms.bean.StudentData;
import com.cg.sms.dao.SmsDaoImpl;
import com.cg.sms.exception.SmsExceptions;

public class AdminSmsImpl implements Istudent {
	StudentData student=new StudentData();
	
	static Scanner scanner= new Scanner(System.in);
	
	public boolean addStudent(StudentData student) throws SmsExceptions {
	SmsDaoImpl dao=new SmsDaoImpl();
	String studentdetails;
	studentdetails=dao.addStudent(student);
	return false;
	
	
	}
	
	
	@Override
	public void modifyStudent()  {
		// TODO Auto-generated method stub
		System.out.println("Modify Student");
	
		System.out.println(student.getRollNo());
		System.out.println(student.getName());
		System.out.println(student.getFee());
		
	}

	

	public void addStudent() throws SmsExceptions {
		// TODO Auto-generated method stub
		
	}
	public boolean isValidData(StudentData student) throws SmsExceptions {
		Pattern namePattern = Pattern.compile("^[A-Z][A-Za-z\\s]{3,10}$");
		Matcher nameMatcher = namePattern.matcher(student.getName());
		boolean isValidName=nameMatcher.matches();
		if(!isValidName){
			throw new SmsExceptions("Name must start with Capital and contains atleast three chars in length.!!");
		}
		Pattern rollnoPattern = Pattern.compile("^[0-9\\d]{1,6}$");
		Matcher rollnoMatcher = rollnoPattern.matcher(student.getRollNo());
		boolean isValidRollNo=rollnoMatcher.matches();
		if(!isValidRollNo){
			throw new SmsExceptions("Roll number must be less than six digits");
		}
		return true;
}


	@Override
	public ArrayList<StudentData> showStudent() {
		// TODO Auto-generated method stub
		return null;
	}

}