package com.cg.sms.service;

import java.util.ArrayList;

import com.cg.sms.bean.StudentData;
import com.cg.sms.exception.SmsExceptions;

public interface Istudent {

		boolean addStudent(StudentData student) throws SmsExceptions;
		void modifyStudent();
		ArrayList<StudentData> showStudent();
	    boolean isValidData(StudentData data) throws SmsExceptions;
}
