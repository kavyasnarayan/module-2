package com.cg.MPS.pl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import javax.swing.text.DateFormatter;

import com.cg.MPS.bean.PurchaseBean;

public class MobileMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MobileMain main=new MobileMain();
		PurchaseBean purchaseBean=new PurchaseBean();
		
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter your name");
		String Name=scanner.next();
		purchaseBean.setCname(Name);
		
		System.out.println("Enter your purchaseId");
		String id= scanner.next();
		purchaseBean.setPurchaseId(id);
		
		System.out.println("Enter your e-mail Id");
		String mail=scanner.next();
		purchaseBean.setMailId(mail);
		
		System.out.println("Enter your 10 digit phone number");
		String pNo=scanner.next();
		purchaseBean.setPhoneNo(pNo);
		
		System.out.println("Enter your mobile purchase date");
		String purdate=scanner.next();
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate date=LocalDate.parse(purdate, formatter);
		
		
	}

}
