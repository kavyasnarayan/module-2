package com.cg.MPS.service;

import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.MPS.Exception.MobileException;
import com.cg.MPS.bean.PurchaseBean;

public class IMobileServiceImpl implements IMobileService{

public boolean isValidate(PurchaseBean bean) throws MobileException{
	
	
	
	/***************************************************************************************************/
	//	Validation methods for data accepted from customer
	/***************************************************************************************************/
	String errormessage="";
	String pid;
	String name;
	String emailId;
	String pNo;
	String date;
	
	/***************************************************************************************************/
	//	Validation for purchase id
	/***************************************************************************************************/
	
	
	/***************************************************************************************************/
	//	Validation for name
	/***************************************************************************************************/
	name=bean.getCname();
	Pattern pattern=Pattern.compile("^[A-Z][A-Za-z\\s]{3,10}$");
	Matcher matcher=pattern.matcher(name);
	if(!matcher.matches()) {
		errormessage+="";
	}
		
	

	/***************************************************************************************************/
	//	Validation for emailid
	/***************************************************************************************************/
	
	
	/***************************************************************************************************/
	//	Validation for phone number
	/***************************************************************************************************/
	
	
	/***************************************************************************************************/
	//	Validation for date
	/***************************************************************************************************/
	return false;
	
}
}
