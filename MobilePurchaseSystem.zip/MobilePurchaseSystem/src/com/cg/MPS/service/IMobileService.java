package com.cg.MPS.service;

public interface IMobileService  {

}
