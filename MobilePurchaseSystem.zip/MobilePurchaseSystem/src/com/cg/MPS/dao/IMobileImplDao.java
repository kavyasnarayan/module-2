package com.cg.MPS.dao;


public class IMobileImplDao  implements IMobileDao {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub

		
	}

}
