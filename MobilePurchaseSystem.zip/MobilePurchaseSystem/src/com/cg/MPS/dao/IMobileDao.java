package com.cg.MPS.dao;

public interface IMobileDao {

}
