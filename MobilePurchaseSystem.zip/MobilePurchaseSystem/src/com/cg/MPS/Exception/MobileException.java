package com.cg.MPS.Exception;

@SuppressWarnings("serial")
public class MobileException extends Exception{

	public MobileException(String message) {
		super(message);
		
	}

}
