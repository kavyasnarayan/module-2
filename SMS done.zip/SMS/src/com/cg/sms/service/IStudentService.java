package com.cg.sms.service;

import com.cg.sms.bean.StudentBean;
import com.cg.sms.exception.StudentException;

public interface IStudentService {
void modifyStudent() throws StudentException;;
void ShowDetails() throws StudentException;
void addStudent(StudentBean student) throws StudentException;
}
