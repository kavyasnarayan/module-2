package com.cg.sms.service;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.Test;

import com.cg.sms.bean.StudentBean;
import com.cg.sms.dao.StudentDaoImpl;
import com.cg.sms.exception.StudentException;



public class StudentServiceImpl implements IStudentService{
StudentDaoImpl input=new StudentDaoImpl();	

@Override
public void addStudent(StudentBean student) throws StudentException{
	input.addStudent(student);
	
}

@Override
public void modifyStudent() throws StudentException{
	// TODO Auto-generated method stub
	
}

@Override
public void ShowDetails() throws StudentException {
	// TODO Auto-generated method stub
	
}

public boolean StudentValidation(StudentBean student) throws StudentException
{
	String errorMessage="";
	String rollno;
	String studentname;
	double fee;
	String dob;
	String mobilenumber;
	
	/*rollno =student.getRollNo();
	Pattern RollPattern=Pattern.compile("^[0-9]{2}$");
	Matcher RollMatcher=RollPattern.matcher(rollno);

	if(!(RollMatcher.matches()))
	{
		errorMessage+="\nRollNo must be 2 digits only";
	}*/
	
	
	mobilenumber=student.getMobileNumber();
	Pattern NumberPattern=Pattern.compile("^[0-9]{10}$");
	Matcher NumberMatcher=NumberPattern.matcher(mobilenumber);
	if(!(NumberMatcher.matches()))
	{
		errorMessage+="\nPlease enter 10 digits.";
	}
	
	/*dob = student.getDOB();
	Pattern DatePattern=Pattern.compile("^[dd-mm-yyyy]$");
	Matcher DateMatcher=DatePattern.matcher(dob);
	
	if(!(DateMatcher.matches()))
	{
		errorMessage+="\nPlease enter the date in mentioned pattern.";
	}*/
	
	studentname=student.getStudentName();
	Pattern namePattern=Pattern.compile("^[A-Z][A-Za-z]{3,10}$");
	Matcher nameMatcher=namePattern.matcher(studentname);
	if(!(nameMatcher.matches()))
	{
	 errorMessage+="\nStudent Name Should have min 3 and max 10 letters and First letter should start with .";
		
	}

	fee=student.getFee();
	if(fee<0)
	{
	errorMessage+="\nThe Fee value must be positive.";

	}
	if(!errorMessage.isEmpty()){
		throw new StudentException(errorMessage);
	}
	return false;


}


}

