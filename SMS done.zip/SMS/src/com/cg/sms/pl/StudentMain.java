package com.cg.sms.pl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.cg.sms.bean.StudentBean;
import com.cg.sms.exception.StudentException;
import com.cg.sms.service.IStudentService;
import com.cg.sms.service.StudentServiceImpl;



public class StudentMain {

	public static void main(String[] args) throws StudentException {

		Scanner scanner=new Scanner(System.in);
		StudentBean student = new StudentBean();
		StudentServiceImpl studentSeviceImpl= new StudentServiceImpl();
		
		int choice;
		 do
	        {
	         System.out.println("1. Add new student");
	         System.out.println("2. Modify student details");
	         System.out.println("3. Show student details");
	         System.out.println("4. Exit");
	               
	         System.out.println("Enter your choice(1-4):");  
	         choice=scanner.nextInt();
	        
			switch (choice) {
	         case 1:
	         System.out.println("Add new student");
				/*System.out.println("Enter the Roll No: ");
				String rollno=scanner.next();
        		student.setRollNo(rollno);*/
			 	            
				 System.out.println("Enter  StudentName: "); 
				 String studentname=scanner.next();
				 student.setStudentName(studentname);  
				            
				 System.out.println("Enter the fee:");  
				 double fee=scanner.nextDouble();
				student.setFee(fee);
				 
				 System.out.println("Enter the DOB:");
				 String dob=scanner.next();
				 student.setDOB(dob);
				 
				 System.out.println("Enter mobile number:");
				 String mobilenumber=scanner.next();
				 student.setMobileNumber(mobilenumber);

			 	 	try 
			 		{
			 	 		
			 			if(studentSeviceImpl.StudentValidation(student)==true){
			 				System.out.println("invalid data");
			 			}
			 			else {
			 				studentSeviceImpl.addStudent(student);
			 			}
			 		} 
			 		catch (StudentException e) 
			 		{
			 			System.err.println(e.getMessage() + ", try again");
			 		}

			 	
	         break;
	                  
	         case 2:
	         System.out.println("Modify student details");
	         
	         System.out.println("Enter the Roll No:");  
	         student.setRollNo(scanner.next());
	         
	         System.out.println("Enter your name:");  
	         student.setStudentName(scanner.next());
	     	 
	         System.out.println("Enter Fee:");  
	         student.setFee(scanner.nextDouble());
	         
	         System.out.println("Enter your DOB:");
	         student.setDOB(scanner.next());
	         
	         System.out.println("Enter mobile number:");
	         student.setMobileNumber(scanner.next());
	         break;
	                
	         case 3:
	         System.out.println("Student details:");

	         System.out.println(student.getRollNo());
	         System.out.println(student.getStudentName());
	         System.out.println(student.getFee());
	         System.out.println(student.getDOB());
	         break;
	                  
	         case 4: break;
	         default:
	         System.out.println("Do you want to continue further?");
	         break;
	         }
	         
	         }while(choice<4);
	         scanner.close();
		
	        
	
	
	
	
	}
	}


