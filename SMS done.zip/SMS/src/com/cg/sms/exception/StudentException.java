package com.cg.sms.exception;

public class StudentException extends Exception{

	
		// TODO Auto-generated method stub
		public StudentException(String message){
			super(message);
		}
	

}
