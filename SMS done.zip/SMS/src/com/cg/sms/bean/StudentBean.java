package com.cg.sms.bean;
import java.time.LocalDate;

import com.cg.sms.pl.StudentMain;
 	
public class StudentBean {
	public StudentBean() {
	}
	
	
	private String rollno;
	private String studentname;
	private double fee;
	private String dob;
	private String mobilenumber;
	
	public String getMobileNumber() {
		return mobilenumber;
	}
	public void setMobileNumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}
	public String getRollNo() {
		return rollno;
	}
	public void setRollNo(String rollno) {
		this.rollno = rollno;
	}
	public String getStudentName() {
		return studentname;
	}
	public void setStudentName(String studentname) {
		this.studentname = studentname;
	}
	public double getFee() {
		return fee;
	}
	public void setFee(double fee) {
		this.fee = fee;
	}
	public String getDOB() {
		return dob;
	}
	public void setDOB(String doj) {
		this.dob = doj;
	}
	
}
