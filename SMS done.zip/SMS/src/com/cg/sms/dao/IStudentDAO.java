package com.cg.sms.dao;

import com.cg.sms.bean.StudentBean;
import com.cg.sms.exception.StudentException;

public interface IStudentDAO {
	public boolean addStudent(StudentBean student) throws StudentException;
	public String modifyStudent(StudentBean student) throws StudentException;
	public String ShowDetails(StudentBean student) throws StudentException;

}
