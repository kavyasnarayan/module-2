package com.cg.sms.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import oracle.jdbc.driver.DBConversion;

import com.cg.sms.bean.StudentBean;
import com.cg.sms.exception.StudentException;

public class StudentDaoImpl implements IStudentDAO{

	@Override
	public boolean addStudent(StudentBean student) throws StudentException {
		
		boolean result= false;
		Properties properties=new Properties();
		InputStream inputStream = null;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			inputStream=new FileInputStream("resources/dbdetails.properties");
			properties.load(inputStream);
			String user=properties.getProperty("username");
			String password=properties.getProperty("password");
			String url=properties.getProperty("url");
			String sql="insert into student(rollno, studentname, fee, mobilenumber, dob) values(std_id.NEXTVAL,?,?,?,sysdate)";
			
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			connection=DriverManager.getConnection(url,user,password);
			connection.setAutoCommit(false);
			preparedStatement=connection.prepareStatement("insert into student(rollno, studentname, fee, mobilenumber, dob) values(std_id.NEXTVAL,?,?,?,sysdate)");
			preparedStatement.setString(1, student.getStudentName());
			System.out.println(student.getStudentName());
			preparedStatement.setDouble(2, student.getFee());
			preparedStatement.setString(3, student.getMobileNumber());
//			preparedStatement.setString(4, student.getDOB());
			int result1=preparedStatement.executeUpdate();
			if(result1==1){
				Statement statement=connection.createStatement();
				ResultSet rs=statement.executeQuery("select std_id.CURRVAL from dual");
				if(rs.next()){
					System.out.println("The student id generated is:"+rs.getInt(1));
				}
				connection.commit();
				System.out.println("Values inserted successfully");
				result=true;
			}
			
		} catch (FileNotFoundException exp) {
			
			throw new StudentException("The file is not found");
		} catch (IOException exp) {
			
			throw new StudentException("IO exception occured");
		} catch (SQLException exp) {
			
			throw new StudentException("SQL exception occured");
		}
		finally{
			if(preparedStatement != null && connection != null){
				try {
					preparedStatement.close();
					connection.close();
				} catch (SQLException e) {
					
					throw new StudentException("SQL exception");
				}
				
			}
		}
		return result;
		
		
	}

	@Override
	public String modifyStudent(StudentBean student) throws StudentException {
		
		return null;
	}

	@Override
	public String ShowDetails(StudentBean student) throws StudentException {
		
		return null;
	}

}

