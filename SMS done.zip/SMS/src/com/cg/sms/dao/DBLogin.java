package com.cg.sms.dao;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Properties;
public class DBLogin {

	
	public static void main(String[] args) throws Exception {
				
				Properties properties=new Properties();
				properties.setProperty("username", "system");
				properties.setProperty("password", "root");
				properties.setProperty("url", "adcd");
				OutputStream outputStream=new FileOutputStream("resources/dbdetails.properties");
				properties.store(outputStream, "login!");
				outputStream.close();
			
			}

		}


	


